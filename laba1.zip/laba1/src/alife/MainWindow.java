package alife;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.Timer;
import java.awt.BorderLayout;
import java.awt.FlowLayout;

public class MainWindow extends JFrame {
    private static final long serialVersionUID = 1L;

    private final Config cfg = new Config();
    private transient Environment env = new Environment(cfg);
    private final GridPanel gridPanel = new GridPanel(env);
    private final JLabel status = new JLabel();
    private final JButton startButton = new JButton("Старт");
    private final Timer timer = new Timer(100, e -> step());

    public MainWindow() {
        super("Искусственная жизнь");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JButton resetButton = new JButton("Сброс");
        JSpinner ping = new JSpinner(new SpinnerNumberModel(100, 10, 2000, 10));
        ping.addChangeListener(e -> timer.setDelay((Integer) ping.getValue()));
        startButton.addActionListener(e -> { if (timer.isRunning()) stop(); else start(); });
        resetButton.addActionListener(e -> reset());

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(startButton);
        top.add(resetButton);
        top.add(new JLabel("Пинг, мс:"));
        top.add(ping);
        top.add(status);

        add(top, BorderLayout.NORTH);
        add(gridPanel, BorderLayout.CENTER);
        updateStatus();
        pack();
        setLocationRelativeTo(null);
    }

    private void start() { timer.start(); startButton.setText("Пауза"); }

    private void stop() { timer.stop(); startButton.setText("Старт"); }

    private void step() {
        env.step();
        if (!env.lifeExists()) stop();
        gridPanel.repaint();
        updateStatus();
    }

    private void reset() {
        stop();
        env = new Environment(cfg);
        gridPanel.setEnvironment(env);
        updateStatus();
    }

    private void updateStatus() {
        status.setText("   Шаг: " + env.getTick() + "   Растения: " + env.count(Kind.PLANT)
                + "   Травоядные: " + env.count(Kind.HERBIVORE) + "   Хищники: " + env.count(Kind.PREDATOR));
    }
}
