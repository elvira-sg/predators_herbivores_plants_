package alife;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;


public class Environment {
    public final Config cfg;
    public final Random rnd;
    private final Agent[][] grid;
    private final List<Agent> agents = new ArrayList<>();
    private final List<Agent> newborn = new ArrayList<>();
    private int tick = 0;

    public Environment(Config cfg) {
        this.cfg = cfg;
        this.rnd = new Random();
        this.grid = new Agent[cfg.height][cfg.width];
        populate();
    }

    private void populate() {
        List<int[]> cells = new ArrayList<>();
        for (int y = 0; y < cfg.height; y++)
            for (int x = 0; x < cfg.width; x++) cells.add(new int[]{x, y});
        Collections.shuffle(cells, rnd);
        int i = 0;
        for (int k = 0; k < cfg.initPlants && i < cells.size(); k++, i++)
            spawn(new Plant(cells.get(i)[0], cells.get(i)[1]));
        for (int k = 0; k < cfg.initHerbivores && i < cells.size(); k++, i++)
            spawn(new Herbivore(cells.get(i)[0], cells.get(i)[1], cfg.herbInitEnergy));
        for (int k = 0; k < cfg.initPredators && i < cells.size(); k++, i++)
            spawn(new Predator(cells.get(i)[0], cells.get(i)[1], cfg.predInitEnergy));
        flushNewborn();
    }

    public int getWidth() { return cfg.width; }
    public int getHeight() { return cfg.height; }
    public int getTick() { return tick; }

    public boolean inside(int x, int y) {
        return x >= 0 && y >= 0 && x < cfg.width && y < cfg.height;
    }

    public Agent at(int x, int y) {
        return inside(x, y) ? grid[y][x] : null;
    }

    public Kind kindAt(int x, int y) {
        if (!inside(x, y)) return Kind.WALL;
        Agent a = grid[y][x];
        return a == null ? Kind.EMPTY : a.kind();
    }


    public void spawn(Agent a) {
        a.attach(this);
        grid[a.getY()][a.getX()] = a;
        newborn.add(a);
    }

    public void moveTo(Agent a, int nx, int ny) {
        grid[a.getY()][a.getX()] = null;
        a.setPosition(nx, ny);
        grid[ny][nx] = a;
    }

    public void remove(Agent a) {
        if (grid[a.getY()][a.getX()] == a) grid[a.getY()][a.getX()] = null;
    }

    public Perception perceive(Agent a) {
        Perception p = new Perception();
        for (int dy = -Perception.RADIUS; dy <= Perception.RADIUS; dy++)
            for (int dx = -Perception.RADIUS; dx <= Perception.RADIUS; dx++)
                p.set(dx, dy, (dx == 0 && dy == 0) ? a.kind() : kindAt(a.getX() + dx, a.getY() + dy));
        return p;
    }

    public void step() {
        List<Agent> order = new ArrayList<>(agents);
        Collections.shuffle(order, rnd);
        for (Agent a : order) {
            if (a.isAlive()) a.act(this);
        }
        agents.removeIf(a -> !a.isAlive());
        flushNewborn();
        tick++;
    }

    private void flushNewborn() {
        agents.addAll(newborn);
        newborn.clear();
    }

    public boolean lifeExists() {
        return count(Kind.HERBIVORE) + count(Kind.PREDATOR) > 0;
    }

    public int count(Kind kind) {
        int n = 0;
        for (Agent a : agents) if (a.kind() == kind && a.isAlive()) n++;
        return n;
    }

    public String render() {
        StringBuilder sb = new StringBuilder();
        for (int y = 0; y < cfg.height; y++) {
            for (int x = 0; x < cfg.width; x++) {
                Kind k = kindAt(x, y);
                sb.append(ansiColor(k)).append(k.symbol()).append("\033[0m ");
            }
            sb.append('\n');
        }
        return sb.toString();
    }

    private static String ansiColor(Kind k) {
        switch (k) {
            case PLANT:     return "\033[32m";     // зелёный
            case HERBIVORE: return "\033[1;96m";   // яркий голубой
            case PREDATOR:  return "\033[1;91m";   // яркий красный
            default:        return "\033[90m";     // серый (пусто)
        }
    }
}
