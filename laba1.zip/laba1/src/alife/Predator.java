package alife;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static alife.Conditions.*;

public class Predator extends Animal {

    private static final List<Rule> RULES = Collections.unmodifiableList(Arrays.asList(
            new Rule(READY_TO_BREED.and(FREE_NEARBY), Action.REPRODUCE),
            new Rule(FOOD_ADJACENT.and(FULL.not()), Action.EAT),
            new Rule(FOOD_VISIBLE.and(FULL.not()), Action.CHASE),
            new Rule(ALWAYS, Action.WANDER)
    ));

    public Predator(int x, int y, int energy) {
        super(x, y, energy);
    }

    @Override public Kind kind() { return Kind.PREDATOR; }
    @Override public Kind foodKind() { return Kind.HERBIVORE; }
    @Override public Kind enemyKind() { return null; }
    @Override public int maxEnergy(Config c) { return c.predMaxEnergy; }
    @Override public int breedThreshold() { return config().predBreedThreshold; }
    @Override protected int stepCost() { return config().predStepCost; }
    @Override protected int foodGain() { return config().predFoodGain; }
    @Override protected List<Rule> rules() { return RULES; }

    @Override
    protected Animal newChild(int x, int y, int energy) {
        return new Predator(x, y, energy);
    }

    public static List<Rule> ruleBase() { return RULES; }
}
