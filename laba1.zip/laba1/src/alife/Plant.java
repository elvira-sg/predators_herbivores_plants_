package alife;

import java.util.List;

public class Plant extends Agent {

    public Plant(int x, int y) {
        super(x, y, 0);
    }

    @Override
    public Kind kind() {
        return Kind.PLANT;
    }

    @Override
    public int maxEnergy(Config cfg) {
        return cfg.plantSpreadThreshold;
    }

    @Override
    public void act(Environment env) {
        Config c = env.cfg;
        energy += c.plantGrowth;
        if (energy < c.plantSpreadThreshold) return;
        List<int[]> free = env.perceive(this).freeAdjacent();
        if (free.isEmpty()) return;               // места нет - энергия продолжает копиться
        int[] d = free.get(env.rnd.nextInt(free.size()));
        env.spawn(new Plant(x + d[0], y + d[1]));
        energy = 0;
    }
}
