package alife;

import java.util.ArrayList;
import java.util.List;

public final class Perception {
    public static final int RADIUS = 2;
    private static final int SIZE = 2 * RADIUS + 1;

    private final Kind[][] view = new Kind[SIZE][SIZE];

    void set(int dx, int dy, Kind kind) {
        view[dy + RADIUS][dx + RADIUS] = kind;
    }

    public Kind at(int dx, int dy) {
        return view[dy + RADIUS][dx + RADIUS];
    }

    public boolean adjacent(Kind kind) {
        return !neighbors(kind).isEmpty();
    }

    public List<int[]> neighbors(Kind kind) {
        List<int[]> res = new ArrayList<>();
        int[][] dirs = {{0, -1}, {0, 1}, {-1, 0}, {1, 0}};
        for (int[] d : dirs) {
            if (at(d[0], d[1]) == kind) res.add(d);
        }
        return res;
    }

    public boolean visible(Kind kind) {
        return nearest(kind) != null;
    }

    public List<int[]> targets(Kind kind, int maxDist) {
        List<int[]> res = new ArrayList<>();
        for (int dy = -RADIUS; dy <= RADIUS; dy++) {
            for (int dx = -RADIUS; dx <= RADIUS; dx++) {
                if ((dx == 0 && dy == 0) || Math.max(Math.abs(dx), Math.abs(dy)) > maxDist) continue;
                if (at(dx, dy) == kind) res.add(new int[]{dx, dy});
            }
        }
        return res;
    }

    public int[] nearest(Kind kind) {
        int[] best = null;
        int bestCheb = Integer.MAX_VALUE, bestEuc = Integer.MAX_VALUE;
        for (int[] t : targets(kind, RADIUS)) {
            int cheb = Math.max(Math.abs(t[0]), Math.abs(t[1]));
            int euc = t[0] * t[0] + t[1] * t[1];
            if (cheb < bestCheb || (cheb == bestCheb && euc < bestEuc)) {
                best = t; bestCheb = cheb; bestEuc = euc;
            }
        }
        return best;
    }

    public List<int[]> freeAdjacent() {
        return neighbors(Kind.EMPTY);
    }
}
