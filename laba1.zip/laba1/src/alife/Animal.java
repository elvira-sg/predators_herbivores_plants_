package alife;

import java.util.ArrayList;
import java.util.List;


public abstract class Animal extends Agent {

    protected Animal(int x, int y, int energy) {
        super(x, y, energy);
    }

    public abstract Kind foodKind();
    public abstract Kind enemyKind();
    public abstract int breedThreshold();
    protected abstract int stepCost();
    protected abstract int foodGain();
    protected abstract List<Rule> rules();
    protected abstract Animal newChild(int x, int y, int energy);

    @Override
    public void act(Environment e) {
        energy -= stepCost();                          // энергия уменьшается каждый шаг
        if (energy <= 0) {                             // исчезновение (смерть)
            die(e);
            return;
        }
        Perception p = e.perceive(this);
        for (Rule rule : rules()) {
            if (rule.condition().test(this, p) && perform(rule.action(), p)) {
                return;
            }
        }
    }

    private boolean perform(Action action, Perception p) {
        switch (action) {
            case FLEE:      return flee(p);
            case EAT:       return eat(p);
            case CHASE:     return chase(p);
            case REPRODUCE: return reproduce(p);
            case WANDER:    return wander(p);
            default:        return false;
        }
    }

    protected boolean cellAllowed(Perception p, int dx, int dy) {
        return true;
    }

    private List<int[]> allowed(List<int[]> cells, Perception p) {
        List<int[]> res = new ArrayList<>();
        for (int[] d : cells) {
            if (cellAllowed(p, d[0], d[1])) res.add(d);
        }
        return res;
    }

    protected boolean eat(Perception p) {
        List<int[]> foods = allowed(p.neighbors(foodKind()), p);
        if (foods.isEmpty()) return false;
        int[] d = foods.get(env.rnd.nextInt(foods.size()));
        Agent victim = env.at(x + d[0], y + d[1]);
        if (victim == null) return false;
        victim.die(env);
        env.moveTo(this, x + d[0], y + d[1]);
        energy = Math.min(maxEnergy(config()), energy + foodGain());
        return true;
    }

    protected boolean chase(Perception p) {
        int[] t = p.nearest(foodKind());
        return t != null && moveBy(p, t[0], t[1], true);
    }

    protected boolean flee(Perception p) {
        if (enemyKind() == null) return false;
        int[] t = p.nearest(enemyKind());
        return t != null && moveBy(p, t[0], t[1], false);
    }

    protected boolean wander(Perception p) {
        List<int[]> free = allowed(p.freeAdjacent(), p);
        if (free.isEmpty()) return false;
        int[] d = free.get(env.rnd.nextInt(free.size()));
        env.moveTo(this, x + d[0], y + d[1]);
        return true;
    }

    protected boolean reproduce(Perception p) {
        List<int[]> free = allowed(p.freeAdjacent(), p);
        if (free.isEmpty()) return false;
        int[] d = free.get(env.rnd.nextInt(free.size()));
        int childEnergy = energy / 2;
        energy -= childEnergy;
        env.spawn(newChild(x + d[0], y + d[1], childEnergy));
        return true;
    }

    private boolean moveBy(Perception p, int tx, int ty, boolean toward) {
        int current = tx * tx + ty * ty;
        List<int[]> best = new ArrayList<>();
        int bestVal = toward ? Integer.MAX_VALUE : Integer.MIN_VALUE;
        for (int[] d : allowed(p.freeAdjacent(), p)) {
            int val = (tx - d[0]) * (tx - d[0]) + (ty - d[1]) * (ty - d[1]);
            if ((toward && val < bestVal) || (!toward && val > bestVal)) {
                bestVal = val;
                best.clear();
            }
            if (val == bestVal) best.add(d);
        }
        if (best.isEmpty()) return false;
        if (toward ? bestVal >= current : bestVal <= current) return false;
        int[] d = best.get(env.rnd.nextInt(best.size()));
        env.moveTo(this, x + d[0], y + d[1]);
        return true;
    }
}
