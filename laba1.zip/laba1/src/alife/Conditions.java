package alife;

public final class Conditions {
    private Conditions() { }

    public static final Condition ALWAYS = Condition.of("true", (a, p) -> true);

    public static final Condition ENEMY_VISIBLE = Condition.of("ВидитВрага",
            (a, p) -> a.enemyKind() != null && p.visible(a.enemyKind()));

    public static final Condition FOOD_ADJACENT = Condition.of("ЕдаРядом",
            (a, p) -> p.adjacent(a.foodKind()));

    public static final Condition FOOD_VISIBLE = Condition.of("ВидитЕду",
            (a, p) -> p.visible(a.foodKind()));

    public static final Condition READY_TO_BREED = Condition.of("ЭнергияВышеПорога",
            (a, p) -> a.getEnergy() >= a.breedThreshold());

    public static final Condition FULL = Condition.of("Сыт",
            (a, p) -> a.getEnergy() >= a.maxEnergy(a.config()));

    public static final Condition FREE_NEARBY = Condition.of("ЕстьСвободнаяКлетка",
            (a, p) -> !p.freeAdjacent().isEmpty());
}
