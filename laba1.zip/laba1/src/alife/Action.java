package alife;

public enum Action {
    FLEE("бежать от врага"),
    EAT("съесть соседний объект"),
    CHASE("двигаться к еде"),
    REPRODUCE("породить потомка"),
    WANDER("случайное перемещение");

    private final String title;

    Action(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        return title;
    }
}
