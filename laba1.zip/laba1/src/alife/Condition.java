package alife;

import java.util.function.BiPredicate;


public final class Condition {
    private final String text;
    private final BiPredicate<Animal, Perception> predicate;

    private Condition(String text, BiPredicate<Animal, Perception> predicate) {
        this.text = text;
        this.predicate = predicate;
    }

    public static Condition of(String name, BiPredicate<Animal, Perception> predicate) {
        return new Condition(name, predicate);
    }

    public boolean test(Animal a, Perception p) {
        return predicate.test(a, p);
    }

    public Condition and(Condition o) {
        return new Condition("(" + text + " ∧ " + o.text + ")", (a, p) -> test(a, p) && o.test(a, p));
    }

    public Condition or(Condition o) {
        return new Condition("(" + text + " ∨ " + o.text + ")", (a, p) -> test(a, p) || o.test(a, p));
    }

    public Condition not() {
        return new Condition("¬" + text, (a, p) -> !test(a, p));
    }

    @Override
    public String toString() {
        return text;
    }
}
