package alife;

public enum Kind {
    EMPTY('.', "Пусто"),
    PLANT('*', "Растение"),
    HERBIVORE('h', "Травоядное"),
    PREDATOR('X', "Хищник"),
    WALL('#', "Граница");

    private final char symbol;
    private final String title;

    Kind(char symbol, String title) {
        this.symbol = symbol;
        this.title = title;
    }

    public char symbol() {
        return symbol;
    }

    public String title() {
        return title;
    }
}
