package alife;

public class Config {
    // --- Среда ---
    public int width = 60;
    public int height = 40;

    public int initPlants = 300;
    public int initHerbivores = 150;
    public int initPredators = 36;

    // --- Растения ---
    public int plantGrowth = 1;
    public int plantSpreadThreshold = 3;

    // --- Травоядные ---
    public int herbInitEnergy = 20;
    public int herbMaxEnergy = 120;
    public int herbBreedThreshold = 60;
    public int herbStepCost = 1;
    public int herbFoodGain = 6;

    // --- Хищники ---
    public int predInitEnergy = 60;
    public int predMaxEnergy = 300;
    public int predBreedThreshold = 200;
    public int predStepCost = 2;
    public int predFoodGain = 75;

}
