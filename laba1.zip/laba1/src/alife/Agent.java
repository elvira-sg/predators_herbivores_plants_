package alife;

public abstract class Agent {
    protected int x, y;
    protected int energy;
    protected boolean alive = true;
    protected Environment env;

    protected Agent(int x, int y, int energy) {
        this.x = x;
        this.y = y;
        this.energy = energy;
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public int getEnergy() { return energy; }
    public boolean isAlive() { return alive; }

    public abstract Kind kind();

    public abstract int maxEnergy(Config cfg);

    public abstract void act(Environment env);

    public void die(Environment env) {
        alive = false;
        env.remove(this);
    }

    void attach(Environment env) {
        this.env = env;
    }

    public Config config() {
        return env.cfg;
    }

    void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
