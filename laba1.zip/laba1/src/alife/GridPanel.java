package alife;

import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

public class GridPanel extends JPanel {
    private static final long serialVersionUID = 1L;
    private static final Color BACKGROUND = new Color(30, 33, 38);
    private static final Color PLANT_COLOR = new Color(70, 190, 90);
    private static final Color HERB_COLOR = new Color(70, 150, 245);
    private static final Color PRED_COLOR = new Color(235, 70, 60);

    private transient Environment env;

    public GridPanel(Environment env) {
        this.env = env;
        setBackground(BACKGROUND);
        setPreferredSize(new Dimension(800, 600));
    }

    public void setEnvironment(Environment env) {
        this.env = env;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int cs = Math.max(2, Math.min(getWidth() / env.getWidth(), getHeight() / env.getHeight()));
        int ox = (getWidth() - cs * env.getWidth()) / 2;
        int oy = (getHeight() - cs * env.getHeight()) / 2;

        g.setColor(new Color(40, 44, 50));
        g.fillRect(ox, oy, cs * env.getWidth(), cs * env.getHeight());

        int pad = Math.max(1, cs / 8);
        for (int y = 0; y < env.getHeight(); y++) {
            for (int x = 0; x < env.getWidth(); x++) {
                Agent a = env.at(x, y);
                if (a == null) continue;
                int px = ox + x * cs, py = oy + y * cs;
                switch (a.kind()) {
                    case PLANT:
                        g.setColor(PLANT_COLOR);
                        g.fillRect(px + pad * 2, py + pad * 2, cs - pad * 4, cs - pad * 4);
                        break;
                    case HERBIVORE:
                        g.setColor(HERB_COLOR);
                        g.fillOval(px + pad, py + pad, cs - 2 * pad, cs - 2 * pad);
                        break;
                    case PREDATOR:
                        g.setColor(PRED_COLOR);
                        g.fillPolygon(new int[]{px + cs / 2, px + cs - pad, px + pad},
                                      new int[]{py + pad, py + cs - pad, py + cs - pad}, 3);
                        break;
                    default:
                        break;
                }
            }
        }
        g.dispose();
    }
}
