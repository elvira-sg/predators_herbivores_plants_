package alife;

import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.PrintStream;


public class ConsoleApp {
    private static final String CLEAR_SCREEN = "\033[2J";
    private static final String CURSOR_HOME = "\033[H";
    private static final String CLEAR_REST = "\033[J";
    private static final String CLEAR_LINE = "\033[K";

    private static final int DEFAULT_PING = 150;

    public static void main(String[] args) throws Exception {
        System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out), true, "UTF-8"));

        int ping = DEFAULT_PING;
        if (args.length > 0) {
            try {
                ping = Integer.parseInt(args[0].trim());
            } catch (NumberFormatException e) {
                System.out.println("Пинг должен быть целым числом (мс). Пример: java -cp out alife.ConsoleApp 100");
                return;
            }
            if (ping < 0) {
                System.out.println("Пинг не может быть отрицательным.");
                return;
            }
        }

        Config cfg = new Config();

        if (System.getProperty("os.name").toLowerCase().contains("win")) {
            new ProcessBuilder("cmd", "/c", "").inheritIO().start().waitFor();
        }

        Environment env = new Environment(cfg);
        System.out.print(CLEAR_SCREEN);
        while (env.lifeExists()) {

            String header = "Шаг " + env.getTick() + " | растения: " + env.count(Kind.PLANT)
                    + " | травоядные: " + env.count(Kind.HERBIVORE)
                    + " | хищники: " + env.count(Kind.PREDATOR);
            String frame = header + "\n" + env.render();
            frame = frame.substring(0, frame.length() - 1).replace("\n", CLEAR_LINE + "\n") + CLEAR_LINE;
            System.out.print(CURSOR_HOME + frame + CLEAR_REST);
            System.out.flush();
            env.step();
            Thread.sleep(ping);
        }
        System.out.println("\nВсе животные погибли.");
    }
}
