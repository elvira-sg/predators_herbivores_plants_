package alife;

public final class Rule {
    private final Condition condition;
    private final Action action;

    public Rule(Condition condition, Action action) {
        this.condition = condition;
        this.action = action;
    }

    public Condition condition() { return condition; }
    public Action action() { return action; }

    @Override
    public String toString() {
        return "ЕСЛИ " + condition + " ТО " + action;
    }
}
