package alife;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static alife.Conditions.*;

public class Herbivore extends Animal {

    private static final List<Rule> RULES = Collections.unmodifiableList(Arrays.asList(
            new Rule(ENEMY_VISIBLE, Action.FLEE),
            new Rule(READY_TO_BREED.and(FREE_NEARBY), Action.REPRODUCE),
            new Rule(FOOD_ADJACENT.and(FULL.not()), Action.EAT),
            new Rule(FOOD_VISIBLE.and(FULL.not()), Action.CHASE),
            new Rule(ALWAYS, Action.WANDER)
    ));

    public Herbivore(int x, int y, int energy) {
        super(x, y, energy);
    }

    @Override public Kind kind() { return Kind.HERBIVORE; }
    @Override public Kind foodKind() { return Kind.PLANT; }
    @Override public Kind enemyKind() { return Kind.PREDATOR; }
    @Override public int maxEnergy(Config c) { return c.herbMaxEnergy; }
    @Override public int breedThreshold() { return config().herbBreedThreshold; }
    @Override protected int stepCost() { return config().herbStepCost; }
    @Override protected int foodGain() { return config().herbFoodGain; }
    @Override protected List<Rule> rules() { return RULES; }


    @Override
    protected boolean cellAllowed(Perception p, int dx, int dy) {
        for (int[] pr : p.targets(Kind.PREDATOR, Perception.RADIUS)) {
            if (!isTrapped(p, pr[0], pr[1])) continue;
            int manhattan = Math.abs(dx - pr[0]) + Math.abs(dy - pr[1]);
            int distAfter = (dx - pr[0]) * (dx - pr[0]) + (dy - pr[1]) * (dy - pr[1]);
            int distNow = pr[0] * pr[0] + pr[1] * pr[1];
            if (manhattan <= 1 || distAfter < distNow) return false;
        }
        return true;
    }

    private boolean isTrapped(Perception p, int px, int py) {
        int[][] dirs = {{0, -1}, {0, 1}, {-1, 0}, {1, 0}};
        for (int[] o : dirs) {
            int qx = px + o[0], qy = py + o[1];
            if (Math.abs(qx) > Perception.RADIUS || Math.abs(qy) > Perception.RADIUS) continue; // не видно - считаем занятой растением
            Kind k = p.at(qx, qy);
            if (k != Kind.PLANT && k != Kind.WALL) return false;
        }
        return true;
    }

    @Override
    protected Animal newChild(int x, int y, int energy) {
        return new Herbivore(x, y, energy);
    }

    public static List<Rule> ruleBase() { return RULES; }
}
